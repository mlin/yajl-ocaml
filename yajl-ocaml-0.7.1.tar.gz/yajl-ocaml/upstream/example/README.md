This directory holds an example of how one might use yajl in the
simplest possible way, to do something like parse and extract values
from a configuration file.

Note that use of the yajl_tree.h utility is completely optional, and
yajl_parse.h offers a lower level stream parsing API that is more
efficient and flexible at the cost of some complexity.
